<?php
//Simple MVC Configuration File
//Inicialização da variável $config
unset($config);
$config = new stdClass();
$config->defaultClass = "Home";
$config->base_url = '/daw2018/comichub/';
$config->url = 'http://localhost'.$config->base_url;
$config->asset = $config->base_url.'view/templates/';
$config->template = 'default';

//FTP: senha nome
//Database
if($_SERVER['HTTP_HOST'] == "localhost"){
	$config->url = 'http://localhost'.$config->base_url;
	$config->dbuser = 'root'; //nomedoaluno
$config->dbpassword = ''; //senha
$config->dbname ='worldniki';//nomedoaluno
$config->dbhost = '127.0.0.1';
$config->dbdrive = 'mysql';
}else{
	$config->url = 'http://200.132.49.218'.$config->base_url;    
$config->dbuser = '2017_daniel'; //nomedoaluno
$config->dbpassword = 'da260604'; //senha
$config->dbname ='2017_daniel';//nomedoaluno
$config->dbhost = '127.0.0.1';
$config->dbdrive = 'mysql';
}











