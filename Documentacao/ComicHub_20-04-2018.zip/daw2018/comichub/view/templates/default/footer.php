
    
    </div>
    <!-- /.container -->

<br>
<br>
<br>
   
    </div>
    <!-- Footer -->
    <footer class="py-4 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; ComicHub 2018 Deus é fiel</p>
        
      </div>
      <!-- /.container -->
    </footer>
   
    
  </body>

</html>