<div class="card">
    <div class="card-header bg-dark text-white">
        <h1 class="text-center">Sucesso!</h1>
    </div>
    <div class="card-body">
        <br>
        <br>
        <br>
        <a href="<?php echo $this->base_url; ?>" style="margin: 0 auto;" class="btn btn-primary">Volver ao Inicio</a>
        <br>
        <br>
        <br>
    </div>
</div>