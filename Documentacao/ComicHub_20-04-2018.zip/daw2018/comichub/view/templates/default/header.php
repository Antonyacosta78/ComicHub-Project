<!DOCTYPE html>
<html lang="pt-BR">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>The Comichub</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo $this->asset;?>vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo $this->asset;?>css/small-business.css" rel="stylesheet">
    <link href="<?php echo $this->asset;?>css/simple-sidebar.css" rel="stylesheet">
    <link rel="stylesheet" href="">
     <!-- Bootstrap core JavaScript -->
    <script src="<?php echo $this->asset;?>vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo $this->asset;?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </head>

  <body>
