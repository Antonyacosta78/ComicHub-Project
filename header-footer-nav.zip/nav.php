<div id="wrapper" class="toggled">
         <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <div class="sidebar-brand">
                    <a href="#">
                      <img class="img-fluid" src="http://placehold.it/75x75" alt="">
                    </a>
                </div>
                <br>
                    <a href="perfil.html"><div id="div-img-user"><img class="img-fluid" id="img-user" src="http://placehold.it/70x70" alt="profile_pic" 
					title="Meu Perfil"></div></a>
                <br>
                <li>
                    <div class="btn-menu text-center" title="Pesquisar Comics"><a href="pesquisacomics.html"><i class="fa fa-search"></i></a></div>
                </li>
                
                <li>
                    <div class="btn-menu text-center" title="Minhas Comics"><a href="minhascomics.html"><i class="fa fa-address-book"></i></a></div>
                </li>
                
                <li>
                    <div class="btn-menu text-center" title="Listas de Leitura"><a href="comicsfavoritas.html"><i class="fa fa-bookmark"></i></a></div>
                </li>
                
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->
    <!-- Page Content -->
    <div id="main-content" class="container">
